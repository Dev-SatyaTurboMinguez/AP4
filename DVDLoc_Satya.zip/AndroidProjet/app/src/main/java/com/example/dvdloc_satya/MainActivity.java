package com.example.dvdloc_satya;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import AeroSpatial.ActiviteModel;
import AeroSpatial.CateAdapter;

public class MainActivity extends AppCompatActivity {

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menugeneral, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId())
        {
            case R.id.menuRechercher:
                Log.i("LocDVD","Menu:rechercher");
                Intent intentRecherche = new Intent(MainActivity.this, recherche.class);
                rechercheLauncher.launch(intentRecherche);
                return true;

            case R.id.menuReserver:
                Log.i("LocDVD", "Menu;reserver atelier");
                Intent intent = new Intent(MainActivity.this, Reservation.class);
                reservationLauncher.launch(intent);

                return true;

            case R.id.menuPresentation:
                Log.i("LocDVD", "Menu:Equipe");
                return true;
        }
        return true;
    }

    ActivityResultLauncher<Intent> reservationLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
            @Override
                public void onActivityResult(ActivityResult result){
                if(result.getResultCode()== Activity.RESULT_OK)
                {
                    Toast.makeText(MainActivity.this, "Réservation confirmée", Toast.LENGTH_SHORT).show();
                }
                    if(result.getResultCode()==Activity.RESULT_CANCELED)
                    {
                        Toast.makeText(MainActivity.this,"Réservation annulée",Toast.LENGTH_SHORT).show();
                    }

            }
            });
    //--------------
    ActivityResultLauncher<Intent>rechercheLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        String titre = data.getStringExtra("titre");
                        Toast.makeText(MainActivity.this, titre, Toast.LENGTH_SHORT).show();
                    }
                }
            });
    //---------------------------------------------------
 protected void onCreate(Bundle saveInstanceState) {
     super.onCreate(saveInstanceState);
     setContentView(R.layout.activity_main);


//======================================
     ListView ListActivite =(ListView) findViewById(R.id.Liste_Activite);
     CateAdapter adapter = new CateAdapter(this,R.layout.ligneact);
     String url ="http://192.168.1.41/api_dvd/server/listeCategories.php";
     final RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());

     JsonObjectRequest jsonObject = new JsonObjectRequest(
             Request.Method.GET,
             url,
             null,
             new Response.Listener<JSONObject>() {
                 @Override
                 public void onResponse(JSONObject response) {
                     try{
                         int count =0;

                         JSONArray ListeCat = response.getJSONArray("data");
                         while(count<ListeCat.length()){
                             JSONObject cat = ListeCat.getJSONObject(count);
                             ActiviteModel Act = new ActiviteModel();
                             Act.setdescriptifAtelier(cat.getString("descriptifAtelier"));


                             adapter.add(Act);
                             count++;

                         }
                     }
                     catch (JSONException e){
                         e.printStackTrace();
                     }
                 }
             },
             new Response.ErrorListener() {
                 @Override
                 public void onErrorResponse(VolleyError error) {
                     error.printStackTrace();
                     Toast.makeText(getApplicationContext(),"Une erreur est survenue",Toast.LENGTH_LONG).show();
                 }
             });
     requestQueue.add(jsonObject);
     ListActivite.setAdapter(adapter);

     //===================================================================================


    // final RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
     //JsonObjectRequest jsonObject = new JsonObjectRequest(
           /*  Request.Method.GET,
             url,
             null,
             new Response.Listener<JSONObject>(){
                 @Override
                 public void onResponse(JSONObject response){
                     int count = 0;

                     try
                     {
                         JSONArray listeCat = response.getJSONArray("data");
                         while(count<listeCat.length()){
                             JSONObject cat = listeCat.getJSONObject(count);
                             String libelle  = cat.getString("descriptifAtelier");
                             Log.i("Libelle", libelle);
                             count++;
                         }
                     }
                     catch(JSONException e){
                         e.printStackTrace();
                     }
                 }

             },
             new Response.ErrorListener(){
                 @Override
                 public void onErrorResponse(VolleyError error)
                 {
                    error.printStackTrace();
                    Toast.makeText(getApplicationContext(), "Une erreur est survenue", Toast.LENGTH_LONG).show();
                 }
             }
     );*/
    //



    /* Button btnPolicier = (Button) findViewById(R.id.btn_policier);
     btnPolicier.setOnClickListener(new Button.OnClickListener() {
         @Override
         public void onClick(View arg0) {
             Toast.makeText(getApplicationContext(), btnPolicier.getText(), Toast.LENGTH_LONG).show();

             btnPolicier.setOnClickListener(new Button.OnClickListener() {
                 @Override
                 public void onClick(View arg0) {
                     final AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
                     alertDialog.setTitle("Construction Maquette");
                     alertDialog.setMessage("Voulez vous consulter l'acitivté Construction Maquette ?");

                     alertDialog.setPositiveButton("Oui", new DialogInterface.OnClickListener() {
                         @Override
                         public void onClick(DialogInterface dialogInterface, int arg1) {
                             Toast.makeText(getApplicationContext(), btnPolicier.getText(), Toast.LENGTH_LONG).show();
                             Intent intent = new Intent(MainActivity.this, ConstructionMaquette.class);
                             startActivity(intent);

                         }
                     });
                     alertDialog.setNegativeButton("Non", new DialogInterface.OnClickListener() {
                         @Override
                         public void onClick(DialogInterface dialogInterface, int arg1) {

                         }
                     });
                     alertDialog.show();
                 }
             });

         }
     });

     //----

     Button btnSerie = (Button) findViewById(R.id.btn_serie);
     btnSerie.setOnClickListener(new Button.OnClickListener() {
         @Override
         public void onClick(View arg0) {
             Toast.makeText(getApplicationContext(), btnSerie.getText(), Toast.LENGTH_LONG).show();

             btnSerie.setOnClickListener(new Button.OnClickListener() {
                 @Override
                 public void onClick(View arg0) {
                     final AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
                     alertDialog.setTitle("Simulation Pilotage");
                     alertDialog.setMessage("Voulez vous consulter l'activité' Simulation Pilotage ?");

                     alertDialog.setPositiveButton("Oui", new DialogInterface.OnClickListener() {
                         @Override
                         public void onClick(DialogInterface dialogInterface, int arg1) {
                             Toast.makeText(getApplicationContext(), btnSerie.getText(), Toast.LENGTH_LONG).show();
                             Intent intent = new Intent(MainActivity.this, SimulationPilotage.class);
                             startActivity(intent);
                         }
                     });
                     alertDialog.setNegativeButton("Non", new DialogInterface.OnClickListener() {
                         @Override
                         public void onClick(DialogInterface dialogInterface, int arg1) {

                         }
                     });
                     alertDialog.show();
                 }
             });
         }
     });

     //-----

     Button btnDocu = (Button) findViewById(R.id.btn_docu);
     btnDocu.setOnClickListener(new Button.OnClickListener() {
         @Override
         public void onClick(View arg0) {
             Toast.makeText(getApplicationContext(), btnDocu.getText(), Toast.LENGTH_LONG).show();

             btnDocu.setOnClickListener(new Button.OnClickListener() {
                 @Override
                 public void onClick(View arg0) {
                     final AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
                     alertDialog.setTitle("JeuVR");
                     alertDialog.setMessage("Voulez vous consulter l'activité' Jeu Réalité Virtuelle ?");

                     alertDialog.setPositiveButton("Oui", new DialogInterface.OnClickListener() {
                         @Override
                         public void onClick(DialogInterface dialogInterface, int arg1) {
                             Toast.makeText(getApplicationContext(), btnDocu.getText(), Toast.LENGTH_LONG).show();
                             Intent intent = new Intent(MainActivity.this, JeuVR.class);
                             startActivity(intent);
                         }
                     });
                     alertDialog.setNegativeButton("Non", new DialogInterface.OnClickListener() {
                         @Override
                         public void onClick(DialogInterface dialogInterface, int arg1) {

                         }
                     });
                     alertDialog.show();
                 }
             });
         }
     }); */

 }


 }