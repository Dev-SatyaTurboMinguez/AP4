package com.example.dvdloc_satya;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class recherche extends AppCompatActivity {
    private Button btnRecherche;
    private EditText edtCherche;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recherche);

        edtCherche = findViewById(R.id.edtRecherche);
        btnRecherche = findViewById(R.id.btn_okCOURS);

        btnRecherche.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Toast toast = Toast.makeText(getApplicationContext(),edtCherche.getText(),Toast.LENGTH_SHORT);
                toast.show();

                Intent intent = new Intent(recherche.this, ConstructionMaquette.class);
                intent.putExtra("titre", edtCherche.getText().toString());
                //setResult(Activity.RESULT_OK,intent);
                startActivity(intent);
                finish();
            }
        });
    }
}