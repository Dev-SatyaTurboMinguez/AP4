package com.example.dvdloc_satya;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Reservation extends AppCompatActivity {
    private Button btnConfirmer;
    private Button btnAnnuler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation);

        btnConfirmer = findViewById(R.id.btn_confirmer);
        btnAnnuler = findViewById(R.id.btn_annuler);

        btnConfirmer.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                setResult((Activity.RESULT_OK));
                finish();
            }
        });
        btnAnnuler.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                setResult((Activity.RESULT_CANCELED));
                finish();
            }
        });
    }
}