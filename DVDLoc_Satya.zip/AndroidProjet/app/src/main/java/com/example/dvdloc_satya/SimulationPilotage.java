package com.example.dvdloc_satya;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.AssetManager;
import android.os.Bundle;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import AeroSpatial.AeroModel;
import AeroSpatial.AeroSpatialAdapter;

public class SimulationPilotage extends AppCompatActivity {

    public String lireLeJson(){
        StringBuilder builder = new StringBuilder();
        AssetManager assetManager;
        InputStreamReader isr;
        BufferedReader data;
        try{
            assetManager = getAssets();
            isr = new InputStreamReader(assetManager.open("simulation.json"));
            data = new BufferedReader(isr);
            String line;
            while((line = data.readLine()) !=null){
                builder.append(line);
            }
        }catch(IOException e){
            e.printStackTrace();
        }
        return builder.toString();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adherents);

        ListView listeSimulation = (ListView) findViewById(R.id.liste_simulation);
        AeroSpatialAdapter adapter = new AeroSpatialAdapter(this, R.layout.ligne);

        String strJson = lireLeJson();
        try{
            JSONArray jsonArray = new JSONArray((strJson));
            for(int i =0;i<jsonArray.length();i++){
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                AeroModel simu = new AeroModel();
                simu.setNomProf(jsonObject.getString("titre"));
                adapter.add(simu);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        listeSimulation.setAdapter((adapter));
    }
}