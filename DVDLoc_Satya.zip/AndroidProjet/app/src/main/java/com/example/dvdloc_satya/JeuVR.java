package com.example.dvdloc_satya;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import org.xmlpull.v1.XmlPullParser;

import AeroSpatial.AeroModel;
import AeroSpatial.AeroSpatialAdapter;

public class JeuVR extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_direction);

        ListView liste_jeu = (ListView) findViewById(R.id.listview_jeuVR);
        AeroSpatialAdapter adapter = new AeroSpatialAdapter(this, R.layout.ligne);
        try{
            XmlPullParser xmlPullParser = getResources().getXml(R.xml.liste_jeu_vr);
            while(xmlPullParser.getEventType() != XmlPullParser.END_DOCUMENT)
            {
                if(xmlPullParser.getEventType() == xmlPullParser.START_TAG)
                {
                    if(xmlPullParser.getName().equals("dvd"))
                    {
                        AeroModel unJeu = new AeroModel();
                        unJeu.setNomCours(xmlPullParser.getAttributeValue(2));
                       // Log.i("LocDVD","Titre ="+ unJeu.getNomCours());

                        unJeu.setNomProf(xmlPullParser.getAttributeValue(0));
                        //int resID = getResources().getIdentifier(xmlPullParser.getAttributeValue(1),"drawable",getPackageName());
                       // unJeu.setImg
                        adapter.add(unJeu);
                    }
                }
                xmlPullParser.next();
            }
        }catch(Exception e){
            Log.i("AeroModel","Erreurs trouvées = " +e.getMessage());
            e.printStackTrace();

        }
        liste_jeu.setAdapter(adapter);
    }
}