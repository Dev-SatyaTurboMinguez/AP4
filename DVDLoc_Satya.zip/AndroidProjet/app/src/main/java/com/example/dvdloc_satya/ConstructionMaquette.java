package com.example.dvdloc_satya;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class ConstructionMaquette extends AppCompatActivity {

    public String partiesAvion[] =
    {
         "Construction Cockpit",
        "Construction ailes/moteurs",
        "Construction intérieur avion",
            "Construction fuselage"
    };
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animateurs);

        final ArrayAdapter<String>adapterList = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_single_choice, partiesAvion);
        ListView listConstruction = (ListView) findViewById(R.id.listView_maquette);
        listConstruction.setAdapter(adapterList);

        listConstruction.setOnItemClickListener(
                new AdapterView.OnItemClickListener()
                {
                    public void onItemClick(AdapterView<?> adapter, View arg1, int position, long arg3)
                    {
                        Toast toast = Toast.makeText(getApplicationContext(),"Position : " +  String.valueOf(position), Toast.LENGTH_SHORT);
                        toast.show();

                        Toast toast2 = Toast.makeText(getApplicationContext(), "Titre : " + partiesAvion[position],Toast.LENGTH_SHORT);
                        toast2.show();
                    }
                }
        );
    }
}