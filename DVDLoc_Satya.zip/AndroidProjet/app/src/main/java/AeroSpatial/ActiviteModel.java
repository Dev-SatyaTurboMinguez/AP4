package AeroSpatial;

public class ActiviteModel {

    public int numAtelier;
    public String descriptifAtelier;

    public ActiviteModel(){}


    public int GetnumAtelier() {return numAtelier;}
    public void setnumAtelier(int numAtelier) {this.numAtelier = numAtelier;}
    public String GetdescriptifAtelier() {return descriptifAtelier;};
    public void setdescriptifAtelier(String descriptifAtelier) {this.descriptifAtelier = descriptifAtelier;};



}
