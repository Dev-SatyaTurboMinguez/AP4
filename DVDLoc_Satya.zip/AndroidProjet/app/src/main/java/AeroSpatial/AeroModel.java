package AeroSpatial;

public class AeroModel
{
    public int idCours;
    public String nomProf;
    public String nomCours;

    public AeroModel(){
    }
    public int getIdCours(){return idCours;}
    public void setIdCours(int idCours){this.idCours = idCours;}

    public String getNomProf(){return nomProf;}
    public void setNomProf(String nomProf){this.nomProf = nomProf;}

    public String getNomCours(){return nomCours;}
    public void setNomCours(String nomCours){this.nomCours = nomCours;}
}
