package AeroSpatial;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;


import com.example.dvdloc_satya.R;

public class CateAdapter extends ArrayAdapter {

    public CateAdapter(@NonNull Context context, int resource) {
        super(context, resource);
    }
    @Override

    public View getView(int Position, View convertview, ViewGroup parent) {
        View result = convertview;
        if (convertview == null) {
            result = LayoutInflater.from(getContext()).inflate(R.layout.ligneact, parent, false);
        }
        ActiviteModel Cate = (ActiviteModel) getItem(Position);

        Button TypeActivite = (Button) result.findViewById(R.id.BtnCate);
        TypeActivite.setText(Cate.GetdescriptifAtelier());



        TypeActivite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Class act =null;
                try{
                    act = Class.forName("com.example.dvdloc_satya."+Cate.descriptifAtelier);
                }catch (ClassNotFoundException e){
                    e.printStackTrace();
                }

                Intent intent = new Intent(getContext(), act);
                intent.putExtra("idCat",Cate.GetnumAtelier());
                getContext().startActivity(intent);
            }
        });
        return result;

    }
    public void Update_Data(){this.notifyDataSetChanged();}
}


